import 'package:flutter_frontend/model/StarLists.dart';

class StarListStore {
  static StarLists? starList;
}
