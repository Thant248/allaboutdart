import 'package:flutter_frontend/model/user_management.dart';

class UserManagementStore {
  static UserManagement? userManagement;
}
