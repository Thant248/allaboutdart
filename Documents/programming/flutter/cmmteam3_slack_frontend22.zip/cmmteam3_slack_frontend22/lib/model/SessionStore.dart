import 'package:flutter_frontend/model/SessionState.dart';

class SessionStore {
  static SessionData? sessionData;
}
