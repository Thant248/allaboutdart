// import 'package:flutter/material.dart';
// import 'package:flutter_frontend/constants.dart';

// class Body extends StatelessWidget {
//   const Body({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Column(
//       children: [
//         Container(
//           padding: const EdgeInsets.all(0.8),
//           color: kPrimaryColor,
//           child: Row(
//             children: [
//               FilledButton(onPressed: (){}, child: const Text( "Recent Message")), 
//               const SizedBox(width: 4,),
//               FilledButton(onPressed: (){}, child: const Text("Active") ), 
//               Expanded(child: )
//             ],
//           ),
//         )
//       ],
//     );
//   }
// }