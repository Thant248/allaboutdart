// import 'package:flutter/material.dart';
// import 'package:flutter_frontend/componnets/Nav.dart';
// import 'package:flutter_frontend/constants.dart';

// class ChatScreen extends StatefulWidget {
//   const ChatScreen({super.key});

//   @override
//   State<ChatScreen> createState() => _ChatScreenState();
// }

// class _ChatScreenState extends State<ChatScreen> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         leading: IconButton(
//           onPressed: () {
//             Navigator.pop(context);
//           },
//           icon: const Icon(Icons.arrow_back_ios),
//         ),
//         title: const Text(
//           "HI",
//           style: const TextStyle(color: Colors.white),
//         ),
//         backgroundColor: kPriamrybackground,
//       ),
//       body: const Body(),
//       floatingActionButton: FloatingActionButton(
//         onPressed: () {},
//         child: const Icon(
//           Icons.person_add_alt_1,
//           color: Colors.white,
//         ),
//       ),
//       bottomNavigationBar: const Nav(),
//     );
//   }
// }
