
class ApiConst {
  static const String mCannel = "http://localhost:8001/m_channels";
}
