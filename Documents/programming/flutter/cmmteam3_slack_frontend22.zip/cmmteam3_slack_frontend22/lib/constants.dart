import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFF6F35A5);
const kPrimaryLightColor = Color(0xFFF1E6FF);
const Color kPrimarybtnColor = Color(0xFF6F6FBC);
const Color kPrimaryTextColor = Colors.black38; // Lavender
const kPriamrybackground = Color.fromARGB(255, 246, 255, 255);
const Color navColor = Color.fromARGB(255, 63, 189, 248);
const double defaultPadding = 16.0;
